package uniandes.dpoo.aerolinea.tiquetes;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class Tiquete {
 
    // Atributos de la clase
    private String codigo;  // Código único para el tiquete
    private Vuelo vuelo;  // Vuelo en el que se usará el tiquete
    private Cliente cliente;  // Cliente que compró el tiquete
    private int tarifa;  // Valor pagado por el tiquete
    private boolean usado;  // Indica si el tiquete ya fue usado


    // Constructor de la clase

    public Tiquete(String codigo, Vuelo vuelo, Cliente clienteComprador, int tarifa) {
        this.codigo = codigo;
        this.vuelo = vuelo;
        this.cliente = clienteComprador;
        this.tarifa = tarifa;
        this.usado = false;  // Inicialmente, el tiquete no está usado
        clienteComprador.agregarTiquete(this);  // Agregamos el tiquete al cliente que lo compró
    }

    // Métodos de la clase

    public String getCodigo() {
        return codigo;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public int getTarifa() {
        return tarifa;
    }

    public boolean esUsado() {
        return usado;
    }

    public void marcarComoUsado() {
        this.usado = true;
    }
}
