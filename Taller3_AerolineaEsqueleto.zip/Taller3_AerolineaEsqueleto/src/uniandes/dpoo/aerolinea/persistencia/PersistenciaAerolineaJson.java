package uniandes.dpoo.aerolinea.persistencia;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.json.JSONArray;
import org.json.JSONObject;

import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;

/**
 * Esta clase implementa la persistencia en formato JSON para la aerolínea.
 */
public class PersistenciaAerolineaJson implements IPersistenciaAerolinea {

    public void cargarAerolinea(String archivo, Aerolinea aerolinea) throws IOException, InformacionInconsistenteException {
        // Leer el archivo en una cadena
        String contenidoArchivo = new String(Files.readAllBytes(Paths.get(archivo)));
        
        // Convertir el contenido en un objeto JSON
        JSONObject jsonAerolinea = new JSONObject(contenidoArchivo);
        
        // Cargar los aviones
        JSONArray jsonAviones = jsonAerolinea.getJSONArray("aviones");
        for (int i = 0; i < jsonAviones.length(); i++) {
            JSONObject jsonAvion = jsonAviones.getJSONObject(i);
            Avion avion = new Avion(jsonAvion.getInt("capacidad"), jsonAvion.getString("nombre"));
            aerolinea.agregarAvion(avion);
        }
        
        // Cargar las rutas
        JSONArray jsonRutas = jsonAerolinea.getJSONArray("rutas");
        for (int i = 0; i < jsonRutas.length(); i++) {
            JSONObject jsonRuta = jsonRutas.getJSONObject(i);
            Aeropuerto origen = aerolinea.getRuta(jsonRuta.getString("codigoRuta")).getOrigen();
            Aeropuerto destino = aerolinea.getRuta(jsonRuta.getString("codigoRuta")).getDestino();
            Ruta ruta = new Ruta(origen, destino, jsonRuta.getString("horaSalida"), jsonRuta.getString("horaLlegada"), jsonRuta.getString("codigoRuta"));
            aerolinea.agregarRuta(ruta);
        }
        
        // Otros elementos de la aerolínea pueden ser cargados de la misma manera...
    }


    public void salvarAerolinea(String archivo, Aerolinea aerolinea) throws IOException {
        // Crear el objeto JSON para la aerolínea
        JSONObject jsonAerolinea = new JSONObject();
        
        // Guardar los aviones
        JSONArray jsonAviones = new JSONArray();
        for (Avion avion : aerolinea.getAviones()) {
            JSONObject jsonAvion = new JSONObject();
            jsonAvion.put("nombre", avion.getNombre());
            jsonAvion.put("capacidad", avion.getCapacidad());
            jsonAviones.put(jsonAvion);
        }
        jsonAerolinea.put("aviones", jsonAviones);
        
        // Guardar las rutas
        JSONArray jsonRutas = new JSONArray();
        for (Ruta ruta : aerolinea.getRutas()) {
            JSONObject jsonRuta = new JSONObject();
            jsonRuta.put("codigoRuta", ruta.getCodigoRuta());
            jsonRuta.put("horaSalida", ruta.getHoraSalida());
            jsonRuta.put("horaLlegada", ruta.getHoraLlegada());
            jsonRutas.put(jsonRuta);
        }
        jsonAerolinea.put("rutas", jsonRutas);
        
        // Escribir el archivo JSON
        Files.write(Paths.get(archivo), jsonAerolinea.toString(4).getBytes());
    }
}
