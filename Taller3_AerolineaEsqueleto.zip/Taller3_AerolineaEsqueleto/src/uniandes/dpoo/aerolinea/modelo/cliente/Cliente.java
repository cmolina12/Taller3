package uniandes.dpoo.aerolinea.modelo.cliente;



import java.util.List;
import java.util.ArrayList;

import uniandes.dpoo.aerolinea.tiquetes.Tiquete;
import uniandes.dpoo.aerolinea.modelo.Vuelo;

public abstract class Cliente {
    
    // Atributos de la clase

    private List<Tiquete> tiquetesSinUsar;
    private List<Tiquete> tiquetesUsados;

    // Constructor de la clase

    public Cliente( )
    {
        // Constructor vacío e inicialización de las listas
        this.tiquetesSinUsar = new ArrayList<>( );
        this.tiquetesUsados = new ArrayList<>( );
    }

    // Métodos de la clase

    public abstract String getIdentificador();
    public abstract String getTipoCliente();


    public void agregarTiquete( Tiquete tiquete )
    {
        tiquetesSinUsar.add( tiquete );
    }

    public int calcularValorTotalTiquetes(){

        int total = 0;

        for (Tiquete tiquete : tiquetesSinUsar) {
            total += tiquete.getTarifa();
        }
        return total;
    }

    public void usarTiquetes(Vuelo vuelo){
        List<Tiquete> tiquetesParaUsar = new ArrayList<>();

        // Recorremos los tiquetes sin usar
        for (Tiquete tiquete : tiquetesSinUsar) {
            // Si el tiquete es para el vuelo que estamos buscando
            if (tiquete.getVuelo().equals(vuelo)) {
                // Agregamos el tiquete a la lista de tiquetes para usar
                tiquetesParaUsar.add(tiquete);
            }
        }


        // Movemos los tiquetes usados a la lista de tiquetes usados
        tiquetesSinUsar.removeAll(tiquetesParaUsar);
        tiquetesUsados.addAll(tiquetesParaUsar);
    }

}


