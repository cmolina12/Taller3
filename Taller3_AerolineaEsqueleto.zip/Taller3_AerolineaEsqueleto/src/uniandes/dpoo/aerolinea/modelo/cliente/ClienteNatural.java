package uniandes.dpoo.aerolinea.modelo.cliente;

public class ClienteNatural extends Cliente{

    public static final String PERSONAL = "Natural"; // Constante que indica el tipo de cliente

    private String nombre; // Nombre del cliente

    // Constructor de la clase

    public ClienteNatural( String nombre )
    {
        super(); // Llama al constructor de la clase Cliente (padre)
        this.nombre = nombre;
    }

    // Métodos de la clase

    public String getIdentificador(){
        // Para un cliente natural, el identificador es el nombre
        return nombre;
    }

    public String getTipoCliente(){
        return PERSONAL;
    }

    public String getNombre(){
        return nombre;
    }
}
