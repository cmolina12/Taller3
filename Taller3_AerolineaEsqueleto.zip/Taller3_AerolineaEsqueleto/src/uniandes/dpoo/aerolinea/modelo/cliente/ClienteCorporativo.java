package uniandes.dpoo.aerolinea.modelo.cliente;

import org.json.JSONObject;

/**
 * Esta clase se usa para representar a los clientes de la aerolínea que son empresas
 */
public class ClienteCorporativo extends Cliente
{
    // Atributos de la clase

    public static final String CORPORATIVO = "Corporativo"; // Constante que indica el tipo de cliente
    public static final int GRANDE = 1; // Constante que indica el tamaño de la empresa
    public static final int MEDIANA = 2; // Constante que indica el tamaño de la empresa
    public static final int PEQUENA = 3; // Constante que indica el tamaño de la empresa

    private String nombreEmpresa; // Nombre de la empresa
    private int tamanoEmpresa; // Tamaño de la empresa

    // Constructor de la clase

    /**
     * Constructor de la clase
     * @param nombreEmpresa El nombre de la empresa
     * @param tamanoEmpresa El tamaño de la empresa
     */

    public ClienteCorporativo( String nombreEmpresa, int tamano )
    {
        super(); // Llama al constructor de la clase Cliente (padre)
        this.nombreEmpresa = nombreEmpresa;
        this.tamanoEmpresa = tamano;
    }

    // Métodos de la clase

    public String getIdentificador(){
        // Para un cliente corporativo, el identificador es el nombre de la empresa
        return nombreEmpresa;
    }   

    public String getTipoCliente(){
        return CORPORATIVO;
    }

    public String getNombreEmpresa(){
        return nombreEmpresa;
    }
    
    public int getTamanoEmpresa(){
        return tamanoEmpresa;
    }
    /**
     * Crea un nuevo objeto de tipo a partir de un objeto JSON.
     * 
     * El objeto JSON debe tener dos atributos: nombreEmpresa (una cadena) y tamanoEmpresa (un número).
     * @param cliente El objeto JSON que contiene la información
     * @return El nuevo objeto inicializado con la información
     */
    public static ClienteCorporativo cargarDesdeJSON( JSONObject cliente )
    {
        String nombreEmpresa = cliente.getString( "nombreEmpresa" );
        int tam = cliente.getInt( "tamanoEmpresa" );
        return new ClienteCorporativo( nombreEmpresa, tam );
    }

    /**
     * Salva este objeto de tipo ClienteCorporativo dentro de un objeto JSONObject para que ese objeto se almacene en un archivo
     * @return El objeto JSON con toda la información del cliente corporativo
     */
    public JSONObject salvarEnJSON( )
    {
        JSONObject jobject = new JSONObject( );
        jobject.put( "nombreEmpresa", this.nombreEmpresa );
        jobject.put( "tamanoEmpresa", this.tamanoEmpresa );
        jobject.put( "tipo", CORPORATIVO );
        return jobject;
    }
}
