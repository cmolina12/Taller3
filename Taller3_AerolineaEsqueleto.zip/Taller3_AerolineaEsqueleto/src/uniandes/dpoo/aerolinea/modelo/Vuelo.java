package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;

public class Vuelo {
    //Atributos de la clase
    private Ruta ruta; //La ruta que cubre el vuelo
    private String fecha; //Formato: AAAA-MM-DD
    private Avion avion;
    private Map<String, Tiquete> tiquetes; //Mapa de tiquetes vendidos, la llave es el código del tiquete

    //Constructor de la clase

    public Vuelo(Ruta ruta, String fecha, Avion avion) {
        this.ruta = ruta;
        this.fecha = fecha;
        this.avion = avion;
        tiquetes = new HashMap<>();
    }

    //Métodos de la clase

    public Ruta getRuta() {
        return ruta;
    }

    public String getFecha() {
        return fecha;
    }

    public Avion getAvion() {
        return avion;
    }

    /**
     * Retorna la coleccion de tiquetes vendidos
     * 
     * @return La coleccion de tiquetes vendidos
     */

    public Collection<Tiquete> getTiquetes(){    
            return tiquetes.values();}

    /**
     * Vende una determinada cantidad de tiquetes para el vuelo y los deja registrados en el mapa de tiquetes
     * 
     * 
     */

     public int venderTiquetse(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) throws VueloSobrevendidoException
     {

         int capacidadDispobible = avion.getCapacidad() - tiquetes.size();

         // Verificar si hay capacidad disponible
            if (cantidad > capacidadDispobible)
            {
                throw new VueloSobrevendidoException(this);
            }

            int total = 0;

            // Vendemos los tiquetse y los agregamos al mapa de tiquetes

            for (int i = 0; i < cantidad; i++)
            {
                String codigoTiquete = generarCodigoTiquete();
                Tiquete tiquete = new Tiquete(codigoTiquete, this, cliente, calculadora.calcularTarifa(this, cliente));
                tiquetes.put(codigoTiquete, tiquete);
                total += tiquete.getTarifa();
            }

            return total;

    }

/** 
 * Genera un código de tiquete único (Implementacion basica)
 */

 private String generarCodigoTiquete()
 {
    return "TQ" + (tiquetes.size()+1); // 
 }

 /**
  * Compara is el vuelo es igual a otro basado en la ruta y la fecha
  */

    public boolean equals(Object obj)
    {
        if (this == obj){
            return true;
        }

        if (obj instanceof Vuelo){
            Vuelo otroVuelo = (Vuelo) obj;
            return this.ruta.equals(otroVuelo.getRuta()) && this.fecha.equals(otroVuelo.getFecha());
        }
        return false;
    }

 }


