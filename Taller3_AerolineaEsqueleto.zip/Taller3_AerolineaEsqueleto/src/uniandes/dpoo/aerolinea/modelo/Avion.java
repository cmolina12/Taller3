package uniandes.dpoo.aerolinea.modelo;

public class Avion {
    private int capacidad;
    private String nombre;

    // Construtor de la clase

    public Avion(int capacidad, String nombre) {
        this.capacidad = capacidad;
        this.nombre = nombre;
    }

    // Metodos de la clase

    public int getCapacidad() {
        return capacidad;
    }

    public String getNombre() {
        return nombre;
    }
}
